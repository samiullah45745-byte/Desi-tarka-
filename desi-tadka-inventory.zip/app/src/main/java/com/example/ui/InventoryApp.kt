package com.example.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.InventoryEntry
import com.example.util.ReceiptImageGenerator

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InventoryApp(
    viewModel: InventoryViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val entries by viewModel.inventoryEntries.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsState()
    
    var currentTab by remember { mutableIntStateOf(0) }
    var showDeleteConfirmDialog by remember { mutableStateOf<InventoryEntry?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.navigationBars
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Hero Restaurant Banner Section with Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_desi_tadka_banner),
                    contentDescription = "Desi Tadka Header",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Linear dark gradient overlay to make text highly readable
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.4f),
                                    Color.Black.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                // Top Floating Control Panel: Language Selector Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.9f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "TADKA / تڑکا",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // In-app English/Urdu Language Switcher
                    Button(
                        onClick = { viewModel.toggleLanguage() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f)
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("language_toggle_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                modifier = Modifier.size(16.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (viewModel.appLanguage == "ur") "ENGLISH" else "اردو",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Header Titles (Bilingual)
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "دیسی تڑکا اینڈ فیملی ریسٹورنٹ",
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "DESI TADKA & FAMILY RESTAURANT",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = viewModel.translate("Inventory & Kitchen Slip System", "انوینٹری اور کچن پرچی سسٹم"),
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        fontStyle = FontStyle.Italic
                    )
                }
            }

            // 2. Navigation Tabs (Material 3 style)
            val tabs = listOf(
                viewModel.translate("ADD ENTRY", "نیا اندراج") to Icons.Default.Add,
                viewModel.translate("HISTORY RECORDS", "ریکارڈ ہسٹری") to Icons.Default.History
            )
            
            ScrollableTabRow(
                selectedTabIndex = currentTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[currentTab]),
                        color = MaterialTheme.colorScheme.primary,
                        height = 3.dp
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, pair ->
                    Tab(
                        selected = currentTab == index,
                        onClick = { currentTab = index },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = pair.second,
                                    contentDescription = pair.first,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = pair.first,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        selectedContentColor = MaterialTheme.colorScheme.primary,
                        unselectedContentColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }

            // 3. Main Body
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp)
            ) {
                when (currentTab) {
                    0 -> AddEntryScreen(
                        viewModel = viewModel,
                        onSaved = { entry ->
                            // Automatically show generated receipt slip
                            viewModel.showReceipt(entry)
                            Toast.makeText(
                                context,
                                viewModel.translate(
                                    "Slip Generated Successfully!",
                                    "سلپ کامیابی سے تیار ہو گئی ہے!"
                                ),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    )
                    1 -> HistoryScreen(
                        viewModel = viewModel,
                        entries = entries,
                        searchQuery = searchQuery,
                        onViewReceipt = { entry ->
                            viewModel.showReceipt(entry)
                        },
                        onDeleteRequest = { entry ->
                            showDeleteConfirmDialog = entry
                        }
                    )
                }
            }
        }

        // 4. Receipt Slip Modal Dialog (Beautiful simulation of printed thermal receipt)
        viewModel.selectedEntryForReceipt?.let { entry ->
            ReceiptDialog(
                entry = entry,
                viewModel = viewModel,
                onDismiss = { viewModel.closeReceipt() },
                onShare = {
                    ReceiptImageGenerator.saveAndShareReceipt(context, entry)
                }
            )
        }

        // Delete Confirmation Dialog
        showDeleteConfirmDialog?.let { entry ->
            AlertDialog(
                onDismissRequest = { showDeleteConfirmDialog = null },
                title = {
                    Text(
                        text = viewModel.translate("Delete Entry", "ریکارڈ حذف کریں"),
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = viewModel.translate(
                            "Are you sure you want to delete this inventory record for '${entry.itemName}'?",
                            "کیا آپ واقعی '${entry.itemName}' کا یہ انوینٹری ریکارڈ حذف کرنا چاہتے ہیں؟"
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteEntry(entry.id)
                            showDeleteConfirmDialog = null
                            Toast.makeText(
                                context,
                                viewModel.translate("Deleted successfully", "ریکارڈ حذف کر دیا گیا"),
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(viewModel.translate("Delete", "حذف کریں"))
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showDeleteConfirmDialog = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text(viewModel.translate("Cancel", "منسوخ"))
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEntryScreen(
    viewModel: InventoryViewModel,
    onSaved: (InventoryEntry) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Presets Panel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(12.dp)
            ) {
                Text(
                    text = viewModel.translate("Kitchen Presets (جلدی انتخاب کریں)", "کچن آئٹمز (فوری انتخاب)"),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.presetItems.forEach { (eng, urdu) ->
                        val label = viewModel.translate(eng, urdu)
                        InputChip(
                            selected = viewModel.itemName.equals(label, ignoreCase = true) || 
                                       viewModel.itemName.equals(eng, ignoreCase = true) ||
                                       viewModel.itemName.equals(urdu, ignoreCase = true),
                            onClick = { 
                                viewModel.itemName = label
                            },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = InputChipDefaults.inputChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Form Inputs Card
        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Item Name Field
                    OutlinedTextField(
                        value = viewModel.itemName,
                        onValueChange = { viewModel.itemName = it },
                        label = { Text(viewModel.translate("Item Name (e.g. Chicken)", "آئٹم کا نام (مثلاً چکن)")) },
                        placeholder = { Text(viewModel.translate("Chicken, Rice, Ghee...", "چکن، چاول، مٹن...")) },
                        leadingIcon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("item_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    // Quantity Row (Quantity input + Unit selection)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = viewModel.quantity,
                            onValueChange = { viewModel.quantity = it },
                            label = { Text(viewModel.translate("Qty", "مقدار")) },
                            placeholder = { Text("10") },
                            leadingIcon = { Icon(Icons.Default.Scale, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Number,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("quantity_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )

                        // Selector Chips for Units
                        Column(
                            modifier = Modifier.weight(1.8f)
                        ) {
                            Text(
                                text = viewModel.translate("Unit / یونٹ", "یونٹ منتخب کریں"),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                viewModel.units.forEach { u ->
                                    val mappedUrdu = viewModel.unitsUrdu[u] ?: u
                                    val uLabel = viewModel.translate(u, mappedUrdu)
                                    InputChip(
                                        selected = viewModel.unit == u,
                                        onClick = { viewModel.unit = u },
                                        label = { Text(uLabel, fontSize = 11.sp, maxLines = 1) },
                                        colors = InputChipDefaults.inputChipColors(
                                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.height(28.dp)
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Optional Pricing Details for robust invoice generation
                    Text(
                        text = viewModel.translate("Optional Details (اضافی معلومات)", "اضافی تفصیلات (آپشنل)"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                    )

                    // Received By (Who accepted in kitchen)
                    OutlinedTextField(
                        value = viewModel.receivedBy,
                        onValueChange = { viewModel.receivedBy = it },
                        label = { Text(viewModel.translate("Received By (e.g. Chef Aslam)", "وصول کنندہ کا نام (مثلاً اسلم شیف)")) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("received_by_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    // Supplier Name
                    OutlinedTextField(
                        value = viewModel.supplierName,
                        onValueChange = { viewModel.supplierName = it },
                        label = { Text(viewModel.translate("Supplier Name", "سپلائر کا نام (جہاں سے مال آیا)")) },
                        leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("supplier_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )

                    // Rate & Total Price Auto-calculation Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = viewModel.ratePerUnit,
                            onValueChange = { viewModel.ratePerUnit = it },
                            label = { Text(viewModel.translate("Rate / unit", "ریٹ فی کلو")) },
                            placeholder = { Text("Rs.") },
                            leadingIcon = { Icon(Icons.Default.PriceCheck, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("rate_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )

                        // If user hasn't explicitly entered a total, we live calculate and hint it
                        val autoCalculatedTotal: String = remember(viewModel.quantity, viewModel.ratePerUnit) {
                            val qty = viewModel.quantity.toDoubleOrNull() ?: 0.0
                            val rate = viewModel.ratePerUnit.toDoubleOrNull() ?: 0.0
                            if (qty > 0.0 && rate > 0.0) "Rs. ${qty * rate}" else ""
                        }

                        OutlinedTextField(
                            value = viewModel.totalPrice,
                            onValueChange = { viewModel.totalPrice = it },
                            label = { Text(viewModel.translate("Total Price", "کل قیمت")) },
                            placeholder = { Text(autoCalculatedTotal.ifEmpty { "Rs." }) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("total_price_input"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                focusedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    // Notes details
                    OutlinedTextField(
                        value = viewModel.notes,
                        onValueChange = { viewModel.notes = it },
                        label = { Text(viewModel.translate("Additional Notes / Remarks", "ریمارکس / ریمارک نوٹس")) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notes_input"),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            focusedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }

        // Action Buttons: Generate Receipt & Clear Form
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Clear Form Button
                Button(
                    onClick = { viewModel.clearForm() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier
                        .height(52.dp)
                        .weight(1f)
                        .testTag("clear_button")
                ) {
                    Text(
                        text = viewModel.translate("Clear Form", "فارم صاف کریں"),
                        fontWeight = FontWeight.Bold
                    )
                }

                // Generate & Save Slip Button
                Button(
                    onClick = {
                        viewModel.saveEntry(
                            onSuccess = { savedEntry ->
                                onSaved(savedEntry)
                            },
                            onError = { errMsg ->
                                Toast.makeText(context, errMsg, Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .height(52.dp)
                        .weight(2.0f)
                        .testTag("submit_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = viewModel.translate("GENERATE SLIP IMAGE", "پرچی امیج بنائیں"),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(
    viewModel: InventoryViewModel,
    entries: List<InventoryEntry>,
    searchQuery: String,
    onViewReceipt: (InventoryEntry) -> Unit,
    onDeleteRequest: (InventoryEntry) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search & Filter Box
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            label = { Text(viewModel.translate("Search Inventory (e.g. Chicken)", "انوینٹری تلاش کریں (مثلاً چکن)")) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear Search")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                focusedLabelColor = MaterialTheme.colorScheme.primary
            )
        )

        // Statistics Summary
        val totalQuantityOfChicken = remember(entries) {
            entries.filter { 
                it.itemName.contains("chicken", ignoreCase = true) || 
                it.itemName.contains("چکن") 
            }.sumOf { it.quantity }
        }
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.08f))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = viewModel.translate(
                    "Showing ${entries.size} logs. Total Chicken Received: $totalQuantityOfChicken KG",
                    "کل ${entries.size} ریکارڈز۔ کل موصول شدہ چکن: $totalQuantityOfChicken کلو"
                ),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        if (entries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = "Empty",
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = viewModel.translate("No Inventory Records Found", "کوئی انوینٹری ریکارڈ نہیں ملا"),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Text(
                        text = viewModel.translate("Logs you save will appear here.", "محفوظ کی گئی پرچیاں یہاں نظر آئیں گی۔"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries, key = { it.id }) { entry ->
                    InventoryItemCard(
                        entry = entry,
                        viewModel = viewModel,
                        onViewReceipt = { onViewReceipt(entry) },
                        onDelete = { onDeleteRequest(entry) }
                    )
                }
            }
        }
    }
}

@Composable
fun InventoryItemCard(
    entry: InventoryEntry,
    viewModel: InventoryViewModel,
    onViewReceipt: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("inventory_item_${entry.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Item Icon badge
            Box(
                modifier = Modifier
                    .size(45.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Receipt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = entry.itemName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${entry.quantity} ${viewModel.translate(entry.unit, viewModel.unitsUrdu[entry.unit] ?: entry.unit)}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = entry.formattedDateTime,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    if (entry.receivedBy.isNotEmpty()) {
                        Text(
                            text = viewModel.translate("By: ${entry.receivedBy}", "وصول کردہ: ${entry.receivedBy}"),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Buttons Column
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onViewReceipt,
                    modifier = Modifier.testTag("view_receipt_${entry.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "View Receipt",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_item_${entry.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun ReceiptDialog(
    entry: InventoryEntry,
    viewModel: InventoryViewModel,
    onDismiss: () -> Unit,
    onShare: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false, // Allow custom sizing
            dismissOnClickOutside = true,
            dismissOnBackPress = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            // Receipt Canvas Panel
            Column(
                modifier = Modifier
                    .widthIn(max = 400.dp)
                    .fillMaxWidth(0.9f)
                    .clickable(enabled = false) {} // Prevent click-through closing
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Thermal Paper Container Card
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    shape = RoundedCornerShape(2.dp), // Receipt sharp cut look
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = Color(0xFFFCFCF8) // Thermal receipt paper off-white
                    ),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 8.dp)
                ) {
                    // Jagged border simulation
                    val teethCount = 30
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .drawBehind {
                                // Draw a dashed top edge or thermal paper style teeth
                                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                drawLine(
                                    color = Color(0xFFD0D0CA),
                                    start = Offset(0f, 0f),
                                    end = Offset(size.width, 0f),
                                    strokeWidth = 4f,
                                    pathEffect = pathEffect
                                )
                                drawLine(
                                    color = Color(0xFFD0D0CA),
                                    start = Offset(0f, size.height),
                                    end = Offset(size.width, size.height),
                                    strokeWidth = 4f,
                                    pathEffect = pathEffect
                                )
                            }
                            .padding(20.dp)
                    ) {
                        LazyColumn(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            item {
                                // Header: Urdu Restaurant Name
                                Text(
                                    text = "دیسی تڑکا اینڈ فیملی ریسٹورنٹ",
                                    color = Color(0xFF212121),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                // Header: English
                                Text(
                                    text = "DESI TADKA & FAMILY RESTAURANT",
                                    color = Color(0xFF212121),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Main G.T. Road Bypass, Gujranwala",
                                    color = Color(0xFF555555),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = "Ph: 0300-1234567, 0321-7654321",
                                    color = Color(0xFF555555),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = Color(0xFF212121), thickness = 1.dp)
                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "INVENTORY SLIP / انوینٹری پرچی",
                                    color = Color(0xFF212121),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                HorizontalDivider(
                                    color = Color(0xFFCCCCCC),
                                    modifier = Modifier.drawBehind {
                                        drawLine(
                                            color = Color(0xFF212121),
                                            start = Offset(0f, size.height),
                                            end = Offset(size.width, size.height),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f),
                                            strokeWidth = 2f
                                        )
                                    }
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            // Receipt key value body
                            item {
                                ReceiptRow(labelEng = "Slip ID", labelUrdu = "پرچی نمبر", value = "#DT-${1000 + entry.id}")
                                ReceiptRow(labelEng = "Date", labelUrdu = "تاریخ", value = entry.formattedDateOnly)
                                ReceiptRow(labelEng = "Time", labelUrdu = "وقت", value = entry.formattedTimeOnly)
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(
                                    color = Color(0xFFCCCCCC),
                                    modifier = Modifier.drawBehind {
                                        drawLine(
                                            color = Color(0xFF212121),
                                            start = Offset(0f, size.height),
                                            end = Offset(size.width, size.height),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f),
                                            strokeWidth = 2f
                                        )
                                    }
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            // Big prominent item quantity rows
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Item / آئٹم:",
                                        color = Color(0xFF212121),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = entry.itemName,
                                        color = Color(0xFF212121),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Quantity / مقدار:",
                                        color = Color(0xFF212121),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${entry.quantity} ${viewModel.translate(entry.unit, viewModel.unitsUrdu[entry.unit] ?: entry.unit)}",
                                        color = Color(0xFF212121),
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            // Optional rows
                            item {
                                if (entry.receivedBy.isNotEmpty()) {
                                    ReceiptRow(labelEng = "Received By", labelUrdu = "وصول کنندہ", value = entry.receivedBy)
                                }
                                if (entry.supplierName.isNotEmpty()) {
                                    ReceiptRow(labelEng = "Supplier", labelUrdu = "سپلائر", value = entry.supplierName)
                                }
                                if (entry.ratePerUnit > 0.0) {
                                    ReceiptRow(labelEng = "Rate per unit", labelUrdu = "ریٹ", value = "Rs. ${entry.ratePerUnit}")
                                }
                                if (entry.totalPrice > 0.0) {
                                    ReceiptRow(labelEng = "Total Price", labelUrdu = "کل قیمت", value = "Rs. ${entry.totalPrice}", isBoldValue = true)
                                } else if (entry.ratePerUnit > 0.0 && entry.quantity > 0.0) {
                                    ReceiptRow(labelEng = "Total Price", labelUrdu = "کل قیمت", value = "Rs. ${entry.quantity * entry.ratePerUnit}", isBoldValue = true)
                                }

                                if (entry.notes.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.Start
                                    ) {
                                        Text(
                                            text = "Notes / تفصیل:",
                                            color = Color(0xFF212121),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = entry.notes,
                                            color = Color(0xFF444444),
                                            fontSize = 12.sp,
                                            fontStyle = FontStyle.Italic,
                                            modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Footer & Signature lines
                            item {
                                Spacer(modifier = Modifier.height(24.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("_________________", color = Color(0xFF888888), fontSize = 10.sp)
                                        Text("سپلائر دستخط", color = Color(0xFF212121), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text("Supplier Sig.", color = Color(0xFF555555), fontSize = 8.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("_________________", color = Color(0xFF888888), fontSize = 10.sp)
                                        Text("وصول کنندہ دستخط", color = Color(0xFF212121), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text("Receiver Sig.", color = Color(0xFF555555), fontSize = 8.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(24.dp))
                                HorizontalDivider(color = Color(0xFF212121), thickness = 1.dp)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "شکریہ! / THANK YOU",
                                    color = Color(0xFF212121),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Receipt Interactive Control buttons (Share and Close)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.25f),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("close_receipt_button")
                    ) {
                        Text(
                            text = viewModel.translate("Close", "بند کریں"),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onShare,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1.8f)
                            .height(48.dp)
                            .testTag("share_receipt_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = viewModel.translate("SHARE SLIP IMAGE", "پرچی امیج بھیجیں"),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(
    labelEng: String,
    labelUrdu: String,
    value: String,
    isBoldValue: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$labelEng ($labelUrdu):",
            color = Color(0xFF555555),
            fontSize = 11.sp
        )
        Text(
            text = value,
            color = Color(0xFF212121),
            fontSize = 12.sp,
            fontWeight = if (isBoldValue) FontWeight.ExtraBold else FontWeight.Bold
        )
    }
}
