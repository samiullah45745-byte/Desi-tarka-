package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Desi Tadka Restaurant Theme Palette
val SpicyCrimson = Color(0xFFC62828)     // Primary: Spicy Red
val SaffronOrange = Color(0xFFEF6C00)    // Secondary: Rich Saffron Tadka
val FreshBasilGreen = Color(0xFF2E7D32)  // Tertiary: Fresh cilantro/greenery
val CharcoalSlate = Color(0xFF212121)    // Dark contrasting text/surfaces

// Light Palette
val WarmWheatBg = Color(0xFFFFFDF7)      // Light clean cream paper tone
val WarmWheatSurface = Color(0xFFFFF9E6) // Warm card/field surfaces
val OnSurfaceDark = Color(0xFF333333)

// Dark Palette (if needed, but a rich warm theme fits best)
val DarkCharcoalBg = Color(0xFF121212)
val DarkCrimsonSurface = Color(0xFF1E1C1A)

