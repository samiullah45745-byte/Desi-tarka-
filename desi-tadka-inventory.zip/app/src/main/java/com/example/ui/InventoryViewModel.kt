package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.InventoryEntry
import com.example.data.InventoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class InventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: InventoryRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = InventoryRepository(database.inventoryDao())
    }

    // Language State: "en" for English, "ur" for Urdu
    var appLanguage by mutableStateOf("ur")
        private set

    fun toggleLanguage() {
        appLanguage = if (appLanguage == "ur") "en" else "ur"
    }

    // Search query state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Observed entries list, automatically updated on search query changes
    val inventoryEntries: StateFlow<List<InventoryEntry>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allEntries
            } else {
                repository.searchEntries(query)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Form states
    var itemName by mutableStateOf("")
    var quantity by mutableStateOf("")
    var unit by mutableStateOf("KG") // Default: KG
    var supplierName by mutableStateOf("")
    var ratePerUnit by mutableStateOf("")
    var totalPrice by mutableStateOf("")
    var receivedBy by mutableStateOf("")
    var notes by mutableStateOf("")

    // Selected entry for viewing/sharing receipt
    var selectedEntryForReceipt by mutableStateOf<InventoryEntry?>(null)
        private set

    fun showReceipt(entry: InventoryEntry) {
        selectedEntryForReceipt = entry
    }

    fun closeReceipt() {
        selectedEntryForReceipt = null
    }

    // Show a quick-add preset item list for Desi Tadka
    val presetItems = listOf(
        "Chicken" to "چکن",
        "Mutton" to "مٹن",
        "Rice" to "چاول",
        "Ghee / Oil" to "گھی / آئل",
        "Potatoes" to "آلو",
        "Onions" to "پیاز",
        "Tomatoes" to "ٹماٹر",
        "Spices" to "مصالحہ جات",
        "Milk" to "دودھ",
        "Yogurt" to "دہی",
        "Flour" to "آٹا",
        "Garlic / Ginger" to "لہسن / ادرک"
    )

    val units = listOf("KG", "Liters", "Dozen", "Pieces", "Bags", "Crates")
    val unitsUrdu = mapOf(
        "KG" to "کلو گرام",
        "Liters" to "لیٹر",
        "Dozen" to "درجن",
        "Pieces" to "عدد / دانے",
        "Bags" to "بوری / تھیلا",
        "Crates" to "کریٹ"
    )

    // Translation helper
    fun translate(eng: String, ur: String): String {
        return if (appLanguage == "ur") ur else eng
    }

    // Validation & Save
    fun saveEntry(onSuccess: (InventoryEntry) -> Unit, onError: (String) -> Unit) {
        if (itemName.trim().isEmpty()) {
            onError(translate("Please enter item name", "براہ کرم آئٹم کا نام درج کریں"))
            return
        }

        val qtyVal = quantity.toDoubleOrNull()
        if (qtyVal == null || qtyVal <= 0.0) {
            onError(translate("Please enter a valid quantity", "براہ کرم درست مقدار درج کریں"))
            return
        }

        val rateVal = ratePerUnit.toDoubleOrNull() ?: 0.0
        val totalVal = totalPrice.toDoubleOrNull() ?: (qtyVal * rateVal)

        viewModelScope.launch {
            val entry = InventoryEntry(
                itemName = itemName.trim(),
                quantity = qtyVal,
                unit = unit,
                supplierName = supplierName.trim(),
                ratePerUnit = rateVal,
                totalPrice = totalVal,
                receivedBy = receivedBy.trim(),
                notes = notes.trim()
            )
            val insertedId = repository.insert(entry)
            val savedEntry = entry.copy(id = insertedId.toInt())
            
            // Clear fields on successful save
            clearForm()
            
            onSuccess(savedEntry)
        }
    }

    fun deleteEntry(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
            if (selectedEntryForReceipt?.id == id) {
                selectedEntryForReceipt = null
            }
        }
    }

    fun clearForm() {
        itemName = ""
        quantity = ""
        supplierName = ""
        ratePerUnit = ""
        totalPrice = ""
        receivedBy = ""
        notes = ""
    }

    // Factory Provider
    class Factory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(InventoryViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return InventoryViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
