package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.InventoryEntry
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object ReceiptImageGenerator {

    fun generateReceiptBitmap(context: Context, entry: InventoryEntry): Bitmap {
        val width = 550
        val height = 780
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Colors
        val paperColor = Color.rgb(252, 252, 248) // Warm off-white receipt paper
        val textColor = Color.rgb(33, 33, 33) // Off-black ink
        val lightGray = Color.rgb(210, 210, 205)

        // Draw Paper Background
        val bgPaint = Paint().apply {
            color = paperColor
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Draw Paper Border (Receipt style)
        val borderPaint = Paint().apply {
            color = lightGray
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRect(5f, 5f, (width - 5).toFloat(), (height - 5).toFloat(), borderPaint)

        // Draw Jagged Top and Bottom cut edges
        val jaggedPaint = Paint().apply {
            color = Color.WHITE // Background color to "cut" the receipt
            style = Paint.Style.FILL
        }
        val toothSize = 10f
        var x = 0f
        while (x < width) {
            // Top teeth
            canvas.drawRect(x, 0f, x + toothSize / 2, toothSize / 2, jaggedPaint)
            // Bottom teeth
            canvas.drawRect(x, height - toothSize / 2, x + toothSize / 2, height.toFloat(), jaggedPaint)
            x += toothSize
        }

        // Paints for text
        val titlePaintUrdu = Paint().apply {
            color = textColor
            textSize = 28f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val titlePaintEnglish = Paint().apply {
            color = textColor
            textSize = 24f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val subtitlePaint = Paint().apply {
            color = textColor
            textSize = 14f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        val sectionTitlePaint = Paint().apply {
            color = textColor
            textSize = 18f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val labelPaint = Paint().apply {
            color = textColor
            textSize = 16f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        val valuePaint = Paint().apply {
            color = textColor
            textSize = 16f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        val linePaint = Paint().apply {
            color = textColor
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }

        val dashedLinePaint = Paint().apply {
            color = lightGray
            strokeWidth = 2f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
        }

        val footerPaint = Paint().apply {
            color = textColor
            textSize = 16f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        var currentY = 50f

        // 1. Restaurant Name Urdu
        canvas.drawText("دیسی تڑکا اینڈ فیملی ریسٹورنٹ", width / 2f, currentY, titlePaintUrdu)
        currentY += 35f

        // 2. Restaurant Name English
        canvas.drawText("DESI TADKA & FAMILY RESTAURANT", width / 2f, currentY, titlePaintEnglish)
        currentY += 25f

        // 3. Subtitle / Tagline
        canvas.drawText("G.T. Road Bypass, Gujranwala", width / 2f, currentY, subtitlePaint)
        currentY += 15f
        canvas.drawText("Ph: 0300-1234567, 0321-7654321", width / 2f, currentY, subtitlePaint)
        currentY += 30f

        // Solid Line
        canvas.drawLine(20f, currentY, (width - 20).toFloat(), currentY, linePaint)
        currentY += 25f

        // Receipt Title
        canvas.drawText("INVENTORY RECEIPT / انوینٹری سلپ", width / 2f, currentY, sectionTitlePaint)
        currentY += 25f

        // Dashed Line
        canvas.drawLine(20f, currentY, (width - 20).toFloat(), currentY, dashedLinePaint)
        currentY += 30f

        // Content drawing helper
        fun drawKeyValueRow(labelEng: String, labelUrdu: String, value: String) {
            val startX = 30f
            val endX = (width - 30).toFloat()

            // Draw label (English + Urdu)
            canvas.drawText("$labelEng ($labelUrdu):", startX, currentY, labelPaint)

            // Draw value (Right aligned)
            val textWidth = valuePaint.measureText(value)
            canvas.drawText(value, endX - textWidth, currentY, valuePaint)

            currentY += 35f
        }

        // Draw Key Values
        drawKeyValueRow("Receipt ID", "سلپ نمبر", "#DT-${1000 + entry.id}")
        drawKeyValueRow("Date", "تاریخ", entry.formattedDateOnly)
        drawKeyValueRow("Time", "وقت", entry.formattedTimeOnly)

        canvas.drawLine(20f, currentY, (width - 20).toFloat(), currentY, dashedLinePaint)
        currentY += 30f

        // Item Detail Row (Large and Prominent)
        val itemPaintLabel = Paint().apply {
            color = textColor
            textSize = 20f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val itemPaintValue = Paint().apply {
            color = textColor
            textSize = 22f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        canvas.drawText("Item / آئٹم:", 30f, currentY, itemPaintLabel)
        val itemNameText = entry.itemName
        val itemNameWidth = itemPaintValue.measureText(itemNameText)
        canvas.drawText(itemNameText, (width - 30) - itemNameWidth, currentY, itemPaintValue)
        currentY += 40f

        canvas.drawText("Quantity / مقدار:", 30f, currentY, itemPaintLabel)
        val qtyText = "${entry.quantity} ${entry.unit}"
        val qtyWidth = itemPaintValue.measureText(qtyText)
        canvas.drawText(qtyText, (width - 30) - qtyWidth, currentY, itemPaintValue)
        currentY += 40f

        // Additional optional rows
        if (entry.supplierName.isNotEmpty()) {
            drawKeyValueRow("Supplier", "سپلائر", entry.supplierName)
        }
        if (entry.receivedBy.isNotEmpty()) {
            drawKeyValueRow("Received By", "وصول کنندہ", entry.receivedBy)
        }
        if (entry.ratePerUnit > 0.0) {
            drawKeyValueRow("Rate", "ریٹ", "Rs. ${entry.ratePerUnit}")
        }
        if (entry.totalPrice > 0.0) {
            drawKeyValueRow("Total Price", "کل قیمت", "Rs. ${entry.totalPrice}")
        } else if (entry.ratePerUnit > 0.0 && entry.quantity > 0.0) {
            val autoTotal = entry.quantity * entry.ratePerUnit
            drawKeyValueRow("Total Price", "کل قیمت", "Rs. $autoTotal")
        }

        if (entry.notes.isNotEmpty()) {
            canvas.drawLine(20f, currentY, (width - 20).toFloat(), currentY, dashedLinePaint)
            currentY += 25f
            canvas.drawText("Notes / تفصیل:", 30f, currentY, labelPaint)
            currentY += 25f
            
            // Text wrapping for notes
            val notesPaint = Paint().apply {
                color = textColor
                textSize = 14f
                isAntiAlias = true
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            }
            val words = entry.notes.split(" ")
            var line = ""
            val maxWidth = width - 60f
            for (word in words) {
                val testLine = if (line.isEmpty()) word else "$line $word"
                if (notesPaint.measureText(testLine) > maxWidth) {
                    canvas.drawText(line, 30f, currentY, notesPaint)
                    currentY += 20f
                    line = word
                } else {
                    line = testLine
                }
            }
            if (line.isNotEmpty()) {
                canvas.drawText(line, 30f, currentY, notesPaint)
                currentY += 25f
            }
        }

        // Space to bottom
        val remainingSpace = height - currentY - 100f
        if (remainingSpace > 0) {
            currentY += remainingSpace / 2f
        } else {
            currentY += 30f
        }

        // Draw Signature Lines
        val sigPaint = Paint().apply {
            color = textColor
            textSize = 12f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        canvas.drawLine(40f, currentY, 180f, currentY, linePaint)
        canvas.drawLine((width - 180).toFloat(), currentY, (width - 40).toFloat(), currentY, linePaint)
        currentY += 15f
        canvas.drawText("سپلائر کے دستخط", 110f, currentY, sigPaint)
        canvas.drawText("وصول کنندہ دستخط", (width - 110).toFloat(), currentY, sigPaint)
        currentY += 15f
        canvas.drawText("Supplier Sig.", 110f, currentY, sigPaint)
        canvas.drawText("Receiver Sig.", (width - 110).toFloat(), currentY, sigPaint)
        currentY += 45f

        // Footer Thank You
        canvas.drawLine(20f, currentY, (width - 20).toFloat(), currentY, linePaint)
        currentY += 25f
        canvas.drawText("شکریہ! / THANK YOU", width / 2f, currentY, footerPaint)

        return bitmap
    }

    fun saveAndShareReceipt(context: Context, entry: InventoryEntry) {
        val bitmap = generateReceiptBitmap(context, entry)
        val cacheDir = File(context.cacheDir, "shared_slips")
        if (!cacheDir.exists()) {
            cacheDir.mkdirs()
        }

        val fileName = "receipt_desi_tadka_${entry.id}_${System.currentTimeMillis()}.png"
        val file = File(cacheDir, fileName)

        try {
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            fos.flush()
            fos.close()

            // Share Intent
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "com.aistudio.desitadkainventory.ksrpzw.fileprovider",
                file
            )

            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_STREAM, uri)
                type = "image/png"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putExtra(Intent.EXTRA_SUBJECT, "Desi Tadka Inventory Slip - DT-${1000 + entry.id}")
                putExtra(Intent.EXTRA_TEXT, "Desi Tadka & Family Restaurant\nInventory received: ${entry.quantity} ${entry.unit} of ${entry.itemName}\nDate/Time: ${entry.formattedDateTime}")
            }

            val chooser = Intent.createChooser(shareIntent, "Share Slip Image / سلپ شیئر کریں")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving slip: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
