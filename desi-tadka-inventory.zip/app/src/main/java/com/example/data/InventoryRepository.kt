package com.example.data

import kotlinx.coroutines.flow.Flow

class InventoryRepository(private val inventoryDao: InventoryDao) {
    val allEntries: Flow<List<InventoryEntry>> = inventoryDao.getAllEntries()

    fun searchEntries(query: String): Flow<List<InventoryEntry>> {
        return inventoryDao.searchEntries("%$query%")
    }

    suspend fun insert(entry: InventoryEntry): Long {
        return inventoryDao.insertEntry(entry)
    }

    suspend fun deleteById(id: Int) {
        inventoryDao.deleteEntryById(id)
    }

    suspend fun deleteAll() {
        inventoryDao.deleteAll()
    }
}
