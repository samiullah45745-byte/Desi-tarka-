package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "inventory_entries")
data class InventoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val itemName: String,
    val quantity: Double,
    val unit: String,
    val timestamp: Long = System.currentTimeMillis(),
    val supplierName: String = "",
    val ratePerUnit: Double = 0.0,
    val totalPrice: Double = 0.0,
    val receivedBy: String = "",
    val notes: String = ""
) {
    val formattedDateTime: String
        get() {
            val sdf = SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

    val formattedTimeOnly: String
        get() {
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

    val formattedDateOnly: String
        get() {
            val sdf = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}
