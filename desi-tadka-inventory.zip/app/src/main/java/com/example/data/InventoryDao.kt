package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_entries ORDER BY timestamp DESC")
    fun getAllEntries(): Flow<List<InventoryEntry>>

    @Query("SELECT * FROM inventory_entries WHERE itemName LIKE :searchQuery ORDER BY timestamp DESC")
    fun searchEntries(searchQuery: String): Flow<List<InventoryEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: InventoryEntry): Long

    @Query("DELETE FROM inventory_entries WHERE id = :id")
    suspend fun deleteEntryById(id: Int)

    @Query("DELETE FROM inventory_entries")
    suspend fun deleteAll()
}
